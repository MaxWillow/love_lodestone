export default {
  map: document.getElementById('map'),
  machPeopleUl: document.querySelector('.mach__people-ul'),
  body: document.querySelector('body'),
  exit: document.querySelector('body'),
  menu: document.querySelector('.js-menu'),
};
